import { NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabase-admin";

const OWNER_EMAIL = "gabrielbzago@gmail.com";

async function getOwner(request: Request) {
  const authorization = request.headers.get("authorization") || "";
  const token = authorization.startsWith("Bearer ") ? authorization.slice(7) : "";
  if (!token) return null;

  const { data: authData, error: authError } = await supabaseAdmin.auth.getUser(token);
  if (authError || !authData.user?.email) return null;

  const email = authData.user.email.trim().toLowerCase();
  const configuredOwners = String(process.env.OWNER_EMAILS || process.env.NEXT_PUBLIC_OWNER_EMAIL || OWNER_EMAIL)
    .split(",")
    .map(v => v.trim().toLowerCase())
    .filter(Boolean);

  if (configuredOwners.includes(email)) return authData.user;

  const { data: row } = await supabaseAdmin
    .from("users")
    .select("id, email, plan")
    .eq("email", email)
    .maybeSingle();

  const role = String(row?.plan || "").toLowerCase();
  return role === "owner" || role === "admin" ? authData.user : null;
}

export async function GET(request: Request) {
  const owner = await getOwner(request);
  if (!owner) return NextResponse.json({ error: "Acesso restrito ao Owner." }, { status: 403 });

  const [users, sales, referrals, payouts] = await Promise.all([
    supabaseAdmin
      .from("users")
      .select("id, name, email, affiliate_code, pix_key, affiliate_balance, affiliate_paid")
      .not("affiliate_code", "is", null),
    supabaseAdmin
      .from("affiliate_sales")
      .select("id, affiliate_code, customer_email, customer_name, plan, amount, commission_amount, stripe_invoice_id, stripe_subscription_id, last_payment_date, created_at, status")
      .order("last_payment_date", { ascending: false }),
    supabaseAdmin
      .from("affiliate_referrals")
      .select("id, affiliate_code, referred_email, referred_name, plan, status, stripe_subscription_id, updated_at, created_at")
      .order("updated_at", { ascending: false }),
    supabaseAdmin
      .from("affiliate_payouts")
      .select("id, affiliate_code, affiliate_email, amount, status, created_at")
      .order("created_at", { ascending: false }),
  ]);

  const firstError = users.error || sales.error || referrals.error || payouts.error;
  if (firstError) {
    console.error("ADMIN AFFILIATE QUERY ERROR", firstError);
    return NextResponse.json({ error: firstError.message }, { status: 500 });
  }

  return NextResponse.json({
    affiliates: users.data || [],
    sales: sales.data || [],
    referrals: referrals.data || [],
    payouts: payouts.data || [],
  });
}

export async function POST(request: Request) {
  const owner = await getOwner(request);
  if (!owner) return NextResponse.json({ error: "Acesso restrito ao Owner." }, { status: 403 });

  const body = await request.json().catch(() => null);
  if (body?.action !== "mark_paid" || !body?.affiliate_id) {
    return NextResponse.json({ error: "Ação inválida." }, { status: 400 });
  }

  const { data: affiliate, error: affiliateError } = await supabaseAdmin
    .from("users")
    .select("id, email, affiliate_code, pix_key, affiliate_balance, affiliate_paid")
    .eq("id", body.affiliate_id)
    .maybeSingle();

  if (affiliateError || !affiliate) {
    return NextResponse.json({ error: affiliateError?.message || "Afiliado não encontrado." }, { status: 404 });
  }

  const amount = Number(affiliate.affiliate_balance || 0);
  if (!Number.isFinite(amount) || amount <= 0) {
    return NextResponse.json({ error: "Não existe saldo pendente para este afiliado." }, { status: 400 });
  }

  const { error: payoutError } = await supabaseAdmin
    .from("affiliate_payouts")
    .insert({
      affiliate_code: affiliate.affiliate_code,
      affiliate_email: affiliate.email,
      amount: Number(amount.toFixed(2)),
      pix_key: affiliate.pix_key,
      status: "paid",
    });

  if (payoutError) {
    console.error("PAYOUT INSERT ERROR", payoutError);
    return NextResponse.json({ error: payoutError.message }, { status: 500 });
  }

  const { error: updateError } = await supabaseAdmin
    .from("users")
    .update({
      affiliate_paid: Number((Number(affiliate.affiliate_paid || 0) + amount).toFixed(2)),
      affiliate_balance: 0,
      last_payout: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    })
    .eq("id", affiliate.id);

  if (updateError) {
    console.error("PAYOUT USER UPDATE ERROR", updateError);
    return NextResponse.json({ error: updateError.message }, { status: 500 });
  }

  return NextResponse.json({ ok: true });
}
